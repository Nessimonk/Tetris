﻿using System;
using System.Collections.Generic;
using System.Threading;

// Класс для представления фигуры (тетромино)
public class Tetromino
{
    // Список всех возможных фигур (матрицы)
    public static readonly List<int[,]> Shapes = new List<int[,]>
    {
        // I-фигура
        new int[,] { {0,0,0,0}, {1,1,1,1}, {0,0,0,0}, {0,0,0,0} },
        // O-фигура
        new int[,] { {1,1}, {1,1} },
        // T-фигура
        new int[,] { {0,1,0}, {1,1,1}, {0,0,0} },
        // S-фигура
        new int[,] { {0,1,1}, {1,1,0}, {0,0,0} },
        // Z-фигура
        new int[,] { {1,1,0}, {0,1,1}, {0,0,0} },
        // J-фигура
        new int[,] { {1,0,0}, {1,1,1}, {0,0,0} },
        // L-фигура
        new int[,] { {0,0,1}, {1,1,1}, {0,0,0} }
    };

    public int[,] Shape { get; set; } // Матрица текущей фигуры
    public int X { get; set; }        // Позиция по горизонтали
    public int Y { get; set; }        // Позиция по вертикали

    // Конструктор: принимает форму фигуры, ставит её в центр сверху
    public Tetromino(int[,] shape)
    {
        Shape = shape;
        X = 3; // Центр по X
        Y = 0; // Верх по Y
    }

    // Метод для вращения фигуры по часовой стрелке
    public void Rotate()
    {
        int n = Shape.GetLength(0); // Количество строк
        int m = Shape.GetLength(1); // Количество столбцов
        int[,] rotated = new int[m, n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < m; j++)
                rotated[j, n - 1 - i] = Shape[i, j];
        Shape = rotated; // Обновляем форму фигуры
    }
}

// Класс для игрового поля
public class GameField
{
    public int Width { get; }  // Ширина поля
    public int Height { get; } // Высота поля
    public int[,] Field { get; set; } // Матрица поля

    // Конструктор: создаёт пустое поле
    public GameField(int width = 10, int height = 20)
    {
        Width = width;
        Height = height;
        Field = new int[height, width];
    }

    // Проверка, можно ли поставить фигуру на поле с заданным смещением
    public bool IsValidPosition(Tetromino tetromino, int offsetX, int offsetY)
    {
        for (int i = 0; i < tetromino.Shape.GetLength(0); i++)
        {
            for (int j = 0; j < tetromino.Shape.GetLength(1); j++)
            {
                if (tetromino.Shape[i, j] == 0) continue; // Пропускаем пустые клетки
                int x = tetromino.X + j + offsetX; // Новая позиция X
                int y = tetromino.Y + i + offsetY; // Новая позиция Y
                // Проверяем выход за границы поля
                if (x < 0 || x >= Width || y < 0 || y >= Height) return false;
                // Проверяем столкновение с уже занятыми клетками
                if (Field[y, x] == 1) return false;
            }
        }
        return true; // Всё хорошо, можно ставить
    }

    // Фиксация фигуры на поле (делаем клетки занятыми)
    public void PlaceTetromino(Tetromino tetromino)
    {
        for (int i = 0; i < tetromino.Shape.GetLength(0); i++)
        {
            for (int j = 0; j < tetromino.Shape.GetLength(1); j++)
            {
                if (tetromino.Shape[i, j] == 1)
                {
                    int x = tetromino.X + j;
                    int y = tetromino.Y + i;
                    if (y >= 0 && y < Height && x >= 0 && x < Width)
                        Field[y, x] = 1; // Помечаем клетку как занятую
                }
            }
        }
    }

    // Удаление заполненных линий
    public void ClearLines()
    {
        for (int i = Height - 1; i >= 0; i--)
        {
            bool full = true; // Предполагаем, что строка заполнена
            for (int j = 0; j < Width; j++)
            {
                if (Field[i, j] == 0)
                {
                    full = false; // Нашли пустую клетку — строка не заполнена
                    break;
                }
            }
            if (full)
            {
                // Сдвигаем все строки выше вниз
                for (int k = i; k > 0; k--)
                    for (int j = 0; j < Width; j++)
                        Field[k, j] = Field[k - 1, j];
                // Верхнюю строку делаем пустой
                for (int j = 0; j < Width; j++)
                    Field[0, j] = 0;
                i++; // Проверяем ту же строку снова, т.к. она теперь новая
            }
        }
    }

    // Отрисовка поля и текущей фигуры
    public void Draw(Tetromino tetromino)
    {
        Console.Clear(); // Очищаем консоль
        for (int i = 0; i < Height; i++)
        {
            for (int j = 0; j < Width; j++)
            {
                bool isTetrominoBlock = false; // Флаг: есть ли тут часть текущей фигуры
                for (int y = 0; y < tetromino.Shape.GetLength(0); y++)
                {
                    for (int x = 0; x < tetromino.Shape.GetLength(1); x++)
                    {
                        // Если координаты совпадают — тут часть фигуры
                        if (tetromino.Shape[y, x] == 1 &&
                            tetromino.Y + y == i &&
                            tetromino.X + x == j)
                        {
                            isTetrominoBlock = true;
                        }
                    }
                }
                // Если тут часть фигуры — рисуем "#", если занято — "#", если пусто — "."
                Console.Write(isTetrominoBlock ? "#" : (Field[i, j] == 1 ? "#" : "."));
            }
            Console.WriteLine(); // Переход на новую строку
        }
    }
}

// Главный класс программы
class Program
{
    static void Main()
    {
        int normalDelay = 500; // Обычная задержка (медленно)
        int fastDelay = 50;    // Быстрое падение
        int currentDelay = normalDelay;
        bool isFastDrop = false;

        while (true)
        {
            GameField field = new GameField();
            Random rnd = new Random();
            Tetromino tetromino = new Tetromino(Tetromino.Shapes[rnd.Next(Tetromino.Shapes.Count)]);
            bool gameOver = false;
            DateTime lastFall = DateTime.Now;

            while (!gameOver)
            {
                field.Draw(tetromino);

                // Проверяем, нажата ли клавиша
                if (Console.KeyAvailable)
                {
                    var keyInfo = Console.ReadKey(true);
                    var key = keyInfo.Key;

                    // Движение влево
                    if (key == ConsoleKey.LeftArrow && field.IsValidPosition(tetromino, -1, 0))
                        tetromino.X--;
                    // Движение вправо
                    else if (key == ConsoleKey.RightArrow && field.IsValidPosition(tetromino, 1, 0))
                        tetromino.X++;
                    // Вращение
                    else if (key == ConsoleKey.UpArrow)
                    {
                        tetromino.Rotate();
                        if (!field.IsValidPosition(tetromino, 0, 0))
                        {
                            for (int i = 0; i < 3; i++) tetromino.Rotate();
                        }
                    }
                    // Ускорение падения при нажатии вниз
                    else if (key == ConsoleKey.DownArrow)
                    {
                        isFastDrop = true;
                    }
                }
                else
                {
                    isFastDrop = false; // Если клавиша не нажата — обычная скорость
                }

                // Выбираем задержку в зависимости от режима
                currentDelay = isFastDrop ? fastDelay : normalDelay;

                // Падение фигуры по таймеру
                if ((DateTime.Now - lastFall).TotalMilliseconds >= currentDelay)
                {
                    if (field.IsValidPosition(tetromino, 0, 1))
                    {
                        tetromino.Y++;
                    }
                    else
                    {
                        field.PlaceTetromino(tetromino);
                        field.ClearLines();
                        tetromino = new Tetromino(Tetromino.Shapes[rnd.Next(Tetromino.Shapes.Count)]);
                        if (!field.IsValidPosition(tetromino, 0, 0))
                        {
                            field.Draw(tetromino);
                            Console.SetCursorPosition(0, field.Height + 1);
                            Console.WriteLine("Игра окончена! Нажмите Enter для новой игры или Esc для выхода.");
                            while (true)
                            {
                                if (Console.KeyAvailable)
                                {
                                    var keyEnd = Console.ReadKey(true).Key;
                                    if (keyEnd == ConsoleKey.Enter)
                                    {
                                        gameOver = true;
                                        break;
                                    }
                                    else if (keyEnd == ConsoleKey.Escape)
                                    {
                                        Environment.Exit(0);
                                    }
                                }
                                Thread.Sleep(50);
                            }
                        }
                    }
                    lastFall = DateTime.Now;
                }

                Thread.Sleep(10); // Очень маленькая задержка для отзывчивости
            }
        }
    }
}
